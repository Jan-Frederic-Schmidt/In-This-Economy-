#!/bin/bash

cd /Users/janschmidt/Library/Developer/Xcode/DerivedData/In_This_Economy\?-hjvmjgyukgrvwxcnzjpwsdijxonp/SourcePackages/artifacts/sparkle/Sparkle

bin/generate_appcast /Volumes/Jan1TB/Coding/Swift/In\ This\ Economy\?/In\ This\ Economy\?/Versions
